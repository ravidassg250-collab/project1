#!/usr/bin/env python
import os
import sys
sys.path.insert(0, os.path.dirname(__file__))

from app import load_jobs, load_internships, DATA_PATH, INTERNSHIP_DATA_PATH

print("=" * 60)
print("DATA FILE PATHS:")
print(f"Jobs CSV: {DATA_PATH}")
print(f"  Exists: {os.path.exists(DATA_PATH)}")
print(f"Internships CSV: {INTERNSHIP_DATA_PATH}")
print(f"  Exists: {os.path.exists(INTERNSHIP_DATA_PATH)}")

print("\n" + "=" * 60)
print("LOADING DATA:")

jobs = load_jobs()
print(f"\nload_jobs() returned:")
print(f"  Type: {type(jobs)}")
print(f"  Length: {len(jobs) if jobs else 'None/Empty'}")
if jobs and len(jobs) > 0:
    print(f"  First job: {jobs[0]}")
else:
    print(f"  No jobs loaded!")

interns = load_internships()
print(f"\nload_internships() returned:")
print(f"  Type: {type(interns)}")
print(f"  Length: {len(interns) if interns else 'None/Empty'}")
if interns and len(interns) > 0:
    print(f"  First internship: {interns[0]}")
else:
    print(f"  No internships loaded!")

print("\n" + "=" * 60)
