import sqlite3
import os

p = os.path.join(os.path.dirname(__file__), '..', 'data.db')
conn = sqlite3.connect(p)
cur = conn.cursor()
cur.execute('''
CREATE TABLE IF NOT EXISTS feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT,
    message TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
''')
conn.commit()
print('Ensured feedback table exists in', p)
conn.close()
