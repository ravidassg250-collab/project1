#!/usr/bin/env python3
"""Reset the `courses` table and insert 40 dummy courses.

Run this from the project root:
    python ai_career_hub\scripts\reset_courses.py
"""
import sqlite3
import os

BASE_DIR = os.path.dirname(os.path.dirname(__file__))
DB_PATH = os.path.join(BASE_DIR, "data.db")

dummy = []
categories = ["Programming", "AI & Data", "IT & Cloud", "Non-IT"]
prices = ["Free", "Paid"]
for i in range(1, 41):
    title = f"Intro to Skill {i}"
    category = categories[i % len(categories)]
    price = prices[i % len(prices)]
    link = f"https://example.com/course/{i}"
    image = f"https://via.placeholder.com/400x160?text=Course+{i}"
    dummy.append((title, category, price, link, image))

def run():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    print("Connected to:", DB_PATH)

    # Ensure table exists (should already exist from app init)
    cur.execute('''
    CREATE TABLE IF NOT EXISTS courses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        category TEXT,
        price TEXT,
        link TEXT,
        image_url TEXT
    )
    ''')

    # Remove rows with empty title and then clear table entirely (user asked dummy replacement)
    cur.execute("DELETE FROM courses")
    conn.commit()
    print("Cleared existing courses table.")

    cur.executemany("INSERT INTO courses (title, category, price, link, image_url) VALUES (?, ?, ?, ?, ?)", dummy)
    conn.commit()
    cur.execute("SELECT COUNT(*) FROM courses")
    count = cur.fetchone()[0]
    print(f"Inserted {count} dummy courses.")

    cur.execute("SELECT id, title, category, price FROM courses LIMIT 5")
    print("Sample rows:")
    for row in cur.fetchall():
        print(row)

    conn.close()

if __name__ == '__main__':
    run()
