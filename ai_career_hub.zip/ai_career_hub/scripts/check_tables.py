import sqlite3
import os

p = os.path.join(os.path.dirname(__file__), '..', 'data.db')
conn = sqlite3.connect(p)
cur = conn.cursor()
cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
tables = [r[0] for r in cur.fetchall()]
print('tables:', tables)
conn.close()
