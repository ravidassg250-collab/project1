import sys
try:
    from flask import Flask, request, jsonify, render_template, session, redirect, url_for, flash
except Exception as e:
    print("Error importing Flask or its dependencies:", e)
    print("Make sure required packages are installed: run `pip install -r requirements.txt`")
    sys.exit(1)

import os
import csv
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
BASE_DIR = os.path.dirname(__file__)
DB_PATH = os.path.join(BASE_DIR, "data.db")
DATA_PATH = os.path.join(BASE_DIR, "data", "ai_job_market_insights.csv")
INTERNSHIP_DATA_PATH = os.path.join(BASE_DIR, "data", "internship.csv")
# Set secret and admin password at import time so sessions work with the reloader
app.config.setdefault("SECRET_KEY", os.environ.get("FLASK_SECRET", "devkey123"))
app.config.setdefault("ADMIN_PASSWORD", os.environ.get("ADMIN_PASSWORD", "ravi@123"))
app.secret_key = app.config.get("SECRET_KEY")
# Admin identity: allow login by user or email
app.config.setdefault("ADMIN_USER", os.environ.get("ADMIN_USER", "ravi092"))
app.config.setdefault("ADMIN_EMAIL", os.environ.get("ADMIN_EMAIL", "admin@localhost"))

# -----------------------------------------------------
# DATABASE HELPER
# -----------------------------------------------------
def execute(query, params=(), fetch=False):
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    cur = conn.cursor()
    cur.execute(query, params)
    rows = cur.fetchall() if fetch else None
    conn.commit()
    conn.close()
    return rows


# -----------------------------------------------------
# CSV LOADERS (kept for tests and fallback to DB)
# -----------------------------------------------------
def load_jobs():
    # Loads jobs from CSV as list[dict]
    if os.path.exists(DATA_PATH):
        out = []
        with open(DATA_PATH, newline='', encoding='utf-8') as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                out.append(row)
        return out
    return []


def load_internships():
    if os.path.exists(INTERNSHIP_DATA_PATH):
        out = []
        with open(INTERNSHIP_DATA_PATH, newline='', encoding='utf-8') as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                out.append(row)
        return out
    return []


def load_courses():
    # Look for courses CSV in a few likely locations
    candidates = [
        os.path.join(BASE_DIR, "data", "coursea_data.csv"),
        os.path.join(BASE_DIR, "data", "courses.csv"),
        os.path.join(BASE_DIR, "data", "courses_export.csv"),
        os.path.join(BASE_DIR, "courses_export.csv"),
        os.path.join(BASE_DIR, "..", "courses_export.csv"),
    ]
    for p in candidates:
        if os.path.exists(p):
            out = []
            with open(p, newline='', encoding='utf-8') as fh:
                reader = csv.DictReader(fh)
                for row in reader:
                    out.append(row)
            return out
    return []


# Safe flash wrapper: some environments may not have sessions available
def safe_flash(message, category=None):
    try:
        if category:
            flash(message, category)
        else:
            flash(message)
    except RuntimeError:
        # sessions/flash not available in this environment; ignore
        pass

# -----------------------------------------------------
# INIT DATABASE
# -----------------------------------------------------
def init_db():
    # Courses Table
    execute("""
    CREATE TABLE IF NOT EXISTS courses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        category TEXT,
        price TEXT,
        link TEXT,
        image_url TEXT
    )
    """)

    # Jobs Table
    execute("""
    CREATE TABLE IF NOT EXISTS jobs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT,
        company TEXT,
        city TEXT,
        salary TEXT,
        description TEXT,
        logo_url TEXT,
        apply_url TEXT
    )
    """)

    # Internships Table
    execute("""
    CREATE TABLE IF NOT EXISTS internships (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company TEXT,
        role TEXT,
        stipend TEXT,
        logo_url TEXT
    )
    """)

    # Feedback Table
    execute("""
    CREATE TABLE IF NOT EXISTS feedback (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT,
        message TEXT,
        rating INTEGER,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    # Ensure rating column exists for older DBs
    try:
        cols = execute("PRAGMA table_info(feedback)", fetch=True)
        col_names = [c['name'] for c in cols]
        if 'rating' not in col_names:
            execute("ALTER TABLE feedback ADD COLUMN rating INTEGER")
    except Exception:
        pass

    # Seed DB from CSVs if tables are empty
    try:
        jobs_count = execute("SELECT COUNT(*) as c FROM jobs", fetch=True)[0]["c"]
    except Exception:
        jobs_count = 0
    if jobs_count == 0:
        jobs = load_jobs()
        for job in jobs:
            execute("INSERT INTO jobs (title, company, city, salary, description) VALUES (?, ?, ?, ?, ?)",
                    (job.get("Job_Title"), job.get("Company", ""), job.get("Location"), job.get("Salary_USD", ""), job.get("Industry", "")))

    try:
        interns_count = execute("SELECT COUNT(*) as c FROM internships", fetch=True)[0]["c"]
    except Exception:
        interns_count = 0
    if interns_count == 0:
        interns = load_internships()
        for intern in interns:
            execute("INSERT INTO internships (company, role, stipend) VALUES (?, ?, ?)",
                    (intern.get("Company Name"), intern.get("Job Role"), intern.get("Stipend")))

    # Seed courses from CSV if empty
    try:
        courses_count = execute("SELECT COUNT(*) as c FROM courses", fetch=True)[0]["c"]
    except Exception:
        courses_count = 0
    if courses_count == 0:
        courses = load_courses()
        for c in courses:
            # CSV may include id column; map expected fields
            title = c.get("title") or c.get("Title") or c.get("name") or ""
            category = c.get("category") or c.get("Category") or ""
            price = c.get("price") or c.get("Price") or ""
            link = c.get("link") or c.get("Link") or ""
            image_url = c.get("image_url") or c.get("image") or c.get("image_url") or ""
            execute("INSERT INTO courses (title, category, price, link, image_url) VALUES (?, ?, ?, ?, ?)",
                    (title, category, price, link, image_url))

    # Users table for simple personalization
    execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        email TEXT UNIQUE,
        role TEXT,
        skills TEXT,
        city TEXT,
        desired TEXT,
        password TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
    """)
    # Ensure older DBs have the password column (SQLite: ALTER TABLE ADD COLUMN is safe when column missing)
    try:
        cols = execute("PRAGMA table_info(users)", fetch=True)
        col_names = [c['name'] for c in cols] if cols else []
        if 'password' not in col_names:
            execute("ALTER TABLE users ADD COLUMN password TEXT")
    except Exception:
        # If pragma fails for some reason, ignore and continue
        pass


# -----------------------------------------------------
# COURSES API (Used by your Filters + Compare + Wishlist)
# -----------------------------------------------------

@app.route("/api/courses", methods=["GET"])
def api_courses():
    rows = execute("SELECT * FROM courses", fetch=True)
    return jsonify([dict(r) for r in rows])


@app.route("/api/courses", methods=["POST"])
def api_add_course():
    d = request.json
    execute("""
        INSERT INTO courses (title, category, price, link, image_url)
        VALUES (?, ?, ?, ?, ?)
    """, (d["title"], d["category"], d["price"], d["link"], d.get("image_url", "")))
    return jsonify({"message": "Course added"}), 201


@app.route("/api/courses/<int:id>", methods=["PUT"])
def api_update_course(id):
    d = request.json
    execute("""
        UPDATE courses
        SET title=?, category=?, price=?, link=?, image_url=?
        WHERE id=?
    """, (d["title"], d["category"], d["price"], d["link"], d.get("image_url", ""), id))
    return jsonify({"message": "Course updated"})


@app.route("/api/courses/<int:id>", methods=["DELETE"])
def api_delete_course(id):
    execute("DELETE FROM courses WHERE id=?", (id,))
    return jsonify({"message": "Course deleted"})


# -----------------------------------------------------
# FRONTEND ROUTES
# -----------------------------------------------------

@app.route("/")
def home():
    # Render the homepage; if a user is logged in, show their name via session
    user_name = session.get('user')
    return render_template("index.html", user=user_name)

@app.route("/courses")
def courses():
    # personalize courses when user is logged in
    user_id = session.get('user_id')
    if user_id:
        urows = execute("SELECT skills FROM users WHERE id=?", (user_id,), fetch=True)
        skills = (urows and urows[0]['skills']) or ''
        if skills:
            parts = [s.strip().lower() for s in skills.split(',') if s.strip()]
            # build WHERE clause matching category or title to skills
            clauses = []
            params = []
            for p in parts:
                clauses.append("lower(category) LIKE ?")
                params.append(f"%{p}%")
                clauses.append("lower(title) LIKE ?")
                params.append(f"%{p}%")
            q = "SELECT * FROM courses WHERE " + " OR ".join(clauses) + " LIMIT 200"
            rows = execute(q, tuple(params), fetch=True)
            if rows:
                return render_template("courses.html", courses=[dict(r) for r in rows], personalized=True)
    rows = execute("SELECT * FROM courses", fetch=True)
    return render_template("courses.html", courses=[dict(r) for r in rows], personalized=False)

@app.route("/jobs")
def jobs():
    # Support filtering by company via query param: /jobs?company=Name
    company_q = (request.args.get('company') or '').strip()
    if company_q:
        rows = execute("SELECT * FROM jobs WHERE lower(company)=?", (company_q.lower(),), fetch=True)
        return render_template("jobs.html", jobs=[dict(r) for r in rows], personalized=False, selected_company=company_q)

    user_id = session.get('user_id')
    if user_id:
        urows = execute("SELECT skills, city FROM users WHERE id=?", (user_id,), fetch=True)
        if urows:
            skills = (urows[0]['skills'] or '').strip()
            city = (urows[0]['city'] or '').strip()
            clauses = []
            params = []
            if city:
                clauses.append("lower(city)=?")
                params.append(city.lower())
            if skills:
                parts = [s.strip().lower() for s in skills.split(',') if s.strip()]
                for p in parts:
                    clauses.append("lower(title) LIKE ?")
                    params.append(f"%{p}%")
                    clauses.append("lower(description) LIKE ?")
                    params.append(f"%{p}%")
            if clauses:
                q = "SELECT * FROM jobs WHERE " + " OR ".join(clauses) + " LIMIT 200"
                rows = execute(q, tuple(params), fetch=True)
                if rows:
                    return render_template("jobs.html", jobs=[dict(r) for r in rows], personalized=True)
    rows = execute("SELECT * FROM jobs", fetch=True)
    # also gather distinct companies for the dropdown
    try:
        comp_rows = execute("SELECT DISTINCT company FROM jobs WHERE company IS NOT NULL AND company != '' ORDER BY lower(company)", fetch=True)
        companies = [r['company'] for r in comp_rows if r['company']]
    except Exception:
        companies = []

    return render_template("jobs.html", jobs=[dict(r) for r in rows], personalized=False, companies=companies, selected_company=None)

@app.route("/internships")
def internships():
    user_id = session.get('user_id')
    if user_id:
        urows = execute("SELECT skills, city FROM users WHERE id=?", (user_id,), fetch=True)
        if urows:
            skills = (urows[0]['skills'] or '').strip()
            city = (urows[0]['city'] or '').strip()
            clauses = []
            params = []
            if city:
                clauses.append("lower(company) LIKE ?")
                params.append(f"%{city.lower()}%")
            if skills:
                parts = [s.strip().lower() for s in skills.split(',') if s.strip()]
                for p in parts:
                    clauses.append("lower(role) LIKE ?")
                    params.append(f"%{p}%")
            if clauses:
                q = "SELECT * FROM internships WHERE " + " OR ".join(clauses) + " LIMIT 200"
                rows = execute(q, tuple(params), fetch=True)
                if rows:
                    return render_template("internships.html", internships=[dict(r) for r in rows], personalized=True)
    rows = execute("SELECT * FROM internships", fetch=True)
    return render_template("internships.html", internships=[dict(r) for r in rows], personalized=False)


# simple user helpers: signup/login/logout and expose current_user to templates
def get_current_user():
    uid = session.get('user_id')
    if not uid:
        return None
    rows = execute("SELECT * FROM users WHERE id=?", (uid,), fetch=True)
    return dict(rows[0]) if rows else None


@app.context_processor
def inject_user():
    return { 'current_user': get_current_user() }


@app.route('/signup', methods=['GET', 'POST'])
def signup():
    # Simpler signup: store user with hashed password in users table and set session
    if request.method == 'POST':
        name = request.form.get('name')
        email = (request.form.get('email') or '').strip()
        password = request.form.get('password')
        if not email:
            flash('Email is required', 'danger')
            return render_template('signup.html')

        # Check if email exists
        existing = execute("SELECT id FROM users WHERE lower(email)=lower(?)", (email,), fetch=True)
        if existing:
            flash('Email already exists', 'danger')
            return render_template('signup.html')

        pwd_hash = generate_password_hash(password) if password else None
        # Insert minimal fields; other columns may be NULL
        execute("INSERT INTO users (name,email,password,created_at) VALUES (?,?,?,datetime('now'))", (name, email, pwd_hash))
        # Fetch id and set session
        u = execute("SELECT id FROM users WHERE lower(email)=lower(?)", (email,), fetch=True)
        if u:
            session['user_id'] = u[0]['id']
            session['user'] = name or email
            flash('Signed up and logged in', 'success')
            return redirect(url_for('home'))
        flash('Could not create account', 'danger')
    return render_template('signup.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    # Simpler login: require email+password and set session
    if request.method == 'POST':
        email = (request.form.get('email') or '').strip()
        password = request.form.get('password') or ''
        if not email or not password:
            flash('Email and password required', 'danger')
            return render_template('login.html')

        # First, allow admin shortcut (admin user/email + admin password)
        admin_user = app.config.get('ADMIN_USER')
        admin_email = app.config.get('ADMIN_EMAIL')
        admin_password = app.config.get('ADMIN_PASSWORD')
        if (email == admin_user or email == admin_email) and password == admin_password:
            # ensure admin user exists
            try:
                execute("INSERT OR IGNORE INTO users (name,email,role,created_at) VALUES (?,?,?,datetime('now'))", (admin_user, admin_email, 'admin'))
            except Exception:
                pass
            u = execute("SELECT id, name FROM users WHERE lower(email)=lower(?)", (admin_email,), fetch=True)
            if u:
                session['user_id'] = u[0]['id']
                session['user'] = u[0]['name'] or admin_email
            resp = redirect(url_for('admin_index'))
            from flask import make_response
            r = make_response(resp)
            r.set_cookie('admin', '1', httponly=True)
            safe_flash('Logged in as admin', 'success')
            return r

        # Regular user login: look up by email and verify stored hashed password
        rows = execute("SELECT id, name, password FROM users WHERE lower(email)=lower(?)", (email,), fetch=True)
        if not rows:
            flash('No account with that email. Please sign up.', 'warning')
            return render_template('login.html')
        r = rows[0]
        stored = r['password'] if 'password' in r.keys() else None
        if not stored:
            flash('This account does not have a password. Please sign up or contact admin.', 'warning')
            return render_template('login.html')
        try:
            if check_password_hash(stored, password):
                session['user_id'] = r['id']
                session['user'] = r['name'] or email
                flash('Logged in', 'success')
                return redirect(url_for('home'))
            else:
                flash('Invalid Email or Password', 'danger')
                return render_template('login.html')
        except Exception:
            flash('Login failed - please try again', 'danger')
            return render_template('login.html')
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('user', None)
    flash('Logged out', 'info')
    return redirect(url_for('login'))


@app.route('/profile', methods=['GET', 'POST'])
def profile():
    uid = session.get('user_id')
    if not uid:
        flash('Please login first', 'warning')
        return redirect(url_for('login'))
    if request.method == 'POST':
        name = request.form.get('name')
        role = request.form.get('role')
        skills = request.form.get('skills')
        city = request.form.get('city')
        desired = request.form.get('desired')
        execute('UPDATE users SET name=?, role=?, skills=?, city=?, desired=? WHERE id=?',
                (name, role, skills, city, desired, uid))
        flash('Profile updated', 'success')
        return redirect(url_for('profile'))
    # GET: render profile
    rows = execute('SELECT * FROM users WHERE id=?', (uid,), fetch=True)
    return render_template('profile.html')

@app.route("/resume-analyzer")
def resume_analyzer():
    return render_template("resume-analyzer.html")

@app.route("/resume-builder")
def resume_builder():
    return render_template("resume-builder.html")

@app.route("/career-predictor")
def career_predictor():
    return render_template("career-predictor.html")


@app.route('/about')
def about():
    return render_template('about.html')


# -----------------------------------------------------
# ADMIN PANEL (very small, session protected)
# -----------------------------------------------------
def admin_required(f):
    from functools import wraps
    @wraps(f)
    def wrapper(*args, **kwargs):
        from flask import request
        if request.cookies.get("admin") != "1":
            return redirect(url_for("admin_login"))
        return f(*args, **kwargs)
    return wrapper


@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        identifier = (request.form.get("user") or "").strip()
        password = request.form.get("password", "")
        # allow login when identifier matches admin user OR admin email and password matches
        if password == app.config.get("ADMIN_PASSWORD") and (identifier == app.config.get("ADMIN_USER") or identifier == app.config.get("ADMIN_EMAIL")):
            from flask import make_response
            resp = make_response(redirect(url_for("admin_index")))
            # set a simple admin cookie (httponly)
            resp.set_cookie("admin", "1", httponly=True)
            safe_flash("Logged in as admin", "success")
            return resp
        flash("Wrong credentials", "error")
    return render_template("admin/login.html")


@app.route("/admin/logout")
def admin_logout():
    from flask import make_response
    resp = make_response(redirect(url_for("admin_login")))
    resp.set_cookie("admin", "", expires=0)
    safe_flash("Logged out", "info")
    return resp


@app.route("/admin")
@admin_required
def admin_index():
    counts = {
        "courses": execute("SELECT COUNT(*) as c FROM courses", fetch=True)[0]["c"],
        "jobs": execute("SELECT COUNT(*) as c FROM jobs", fetch=True)[0]["c"],
        "internships": execute("SELECT COUNT(*) as c FROM internships", fetch=True)[0]["c"],
        "feedback": execute("SELECT COUNT(*) as c FROM feedback", fetch=True)[0]["c"]
    }
    # fetch recent feedback entries (most recent 5)
    recent = execute("SELECT id, name, message, rating, created_at FROM feedback ORDER BY created_at DESC LIMIT 5", fetch=True)
    recent_feedback = [dict(r) for r in recent] if recent else []
    return render_template("admin/index.html", counts=counts, recent_feedback=recent_feedback)


@app.route('/admin/about')
@admin_required
def admin_about():
    return render_template('admin/about.html')


@app.route('/admin/chart-data')
@admin_required
def admin_chart_data():
    # Aggregated counts for admin dashboard charts
    # Courses by category
    rows = execute("SELECT category, COUNT(*) as c FROM courses GROUP BY category ORDER BY c DESC", fetch=True)
    courses_labels = [r['category'] or 'Unspecified' for r in rows]
    courses_counts = [r['c'] for r in rows]

    # Jobs by city (top 10)
    rows = execute("SELECT city, COUNT(*) as c FROM jobs GROUP BY city ORDER BY c DESC LIMIT 10", fetch=True)
    jobs_labels = [r['city'] or 'Unspecified' for r in rows]
    jobs_counts = [r['c'] for r in rows]

    # Internships by company (top 10)
    rows = execute("SELECT company, COUNT(*) as c FROM internships GROUP BY company ORDER BY c DESC LIMIT 10", fetch=True)
    intern_labels = [r['company'] or 'Unspecified' for r in rows]
    intern_counts = [r['c'] for r in rows]

    from flask import jsonify
    return jsonify({
        'courses': {'labels': courses_labels, 'counts': courses_counts},
        'jobs': {'labels': jobs_labels, 'counts': jobs_counts},
        'internships': {'labels': intern_labels, 'counts': intern_counts}
    })


# Simple chatbot endpoint for public pages
@app.route('/chat', methods=['POST'])
def chat():
    data = request.get_json(silent=True) or {}
    msg = (data.get('message') or '').strip()
    # Very small rule-based responder
    reply = "Sorry, I didn't understand that. I can help with courses, jobs and internships."
    if not msg:
        reply = "Please type a question about courses, jobs, or internships."
    else:
        lm = msg.lower()
        if 'course' in lm or 'courses' in lm:
            # give quick link and top categories
            rows = execute("SELECT category, COUNT(*) as c FROM courses GROUP BY category ORDER BY c DESC LIMIT 5", fetch=True)
            cats = [r['category'] or 'Unspecified' for r in rows]
            if cats:
                reply = f"Top course categories: {', '.join(cats)}. Browse all courses at /courses"
            else:
                reply = "No course data available right now. Try again later."
        elif 'job' in lm or 'jobs' in lm or 'company' in lm:
            rows = execute("SELECT city, COUNT(*) as c FROM jobs GROUP BY city ORDER BY c DESC LIMIT 5", fetch=True)
            places = [r['city'] or 'Unspecified' for r in rows]
            if places:
                reply = f"Top cities with job listings: {', '.join(places)}. Browse jobs at /jobs"
            else:
                reply = "No job data available right now."
        elif 'intern' in lm:
            rows = execute("SELECT company, COUNT(*) as c FROM internships GROUP BY company ORDER BY c DESC LIMIT 5", fetch=True)
            comps = [r['company'] or 'Unspecified' for r in rows]
            if comps:
                reply = f"Top internship providers: {', '.join(comps)}. Browse internships at /internships"
            else:
                reply = "No internship data available right now."
        elif 'help' in lm or 'how' in lm:
            reply = "Ask me things like: 'show courses in data', 'find jobs in Bangalore', or 'list internships'."
        else:
            # fallback echo with suggestion
            reply = "I can help with courses, jobs and internships. Try: 'show courses' or 'list jobs'."

    return jsonify({'reply': reply})



@app.route('/feedback', methods=['GET', 'POST'])
def feedback():
    # GET: render feedback page; POST: store feedback
    if request.method == 'GET':
        return render_template('feedback.html')

    # POST handling (JSON or form)
    if request.is_json:
        data = request.get_json()
        name = (data.get('name') or '').strip()
        email = (data.get('email') or '').strip()
        message = (data.get('message') or '').strip()
        rating = data.get('rating')
        try:
            rating = int(rating) if rating is not None and str(rating).strip()!='' else None
        except Exception:
            rating = None
    else:
        name = (request.form.get('name') or '').strip()
        email = (request.form.get('email') or '').strip()
        message = (request.form.get('message') or '').strip()
        rating = request.form.get('rating')
        try:
            rating = int(rating) if rating is not None and str(rating).strip()!='' else None
        except Exception:
            rating = None

    if not message:
        if request.is_json:
            return jsonify({'error': 'Message required'}), 400
        safe_flash('Please enter a feedback message', 'error')
        return redirect(request.referrer or url_for('home'))

    execute("INSERT INTO feedback (name, email, message, rating) VALUES (?, ?, ?, ?)", (name, email, message, rating))

    if request.is_json:
        return jsonify({'message': 'Thank you for your feedback'}), 201
    safe_flash('Thank you for your feedback', 'success')
    return redirect(request.referrer or url_for('home'))


# Simple CRUD helpers for courses and others
@app.route("/admin/courses")
@admin_required
def admin_courses():
    rows = execute("SELECT * FROM courses", fetch=True)
    return render_template(
        "admin/list.html",
        title="Courses",
        rows=[dict(r) for r in rows],
        add_url="admin_add_course",
        edit_url_base="admin_edit_course",
        delete_url_base="admin_delete_course"
    )


@app.route('/admin/export/<string:which>')
@admin_required
def admin_export(which):
    # allow exporting courses, jobs, internships as CSV
    mapping = {
        'courses': ('courses', ['id','title','category','price','link','image_url']),
        'jobs': ('jobs', ['id','title','company','city','salary','description','logo_url','apply_url']),
        'internships': ('internships', ['id','company','role','stipend','logo_url'])
    }
    # allow exporting feedback
    if which == 'feedback':
        cols = ['id','name','email','message','rating','created_at']
        rows = execute(f"SELECT {','.join(cols)} FROM feedback", fetch=True)
        from io import StringIO
        si = StringIO()
        writer = csv.writer(si)
        writer.writerow(cols)
        for r in rows:
            writer.writerow([r[c] for c in cols])
        output = si.getvalue()
        from flask import Response
        return Response(output, mimetype='text/csv', headers={
            'Content-Disposition': f'attachment; filename="feedback.csv"'
        })
    if which not in mapping:
        safe_flash('Unknown export type', 'error')
        return redirect(url_for('admin_index'))
    table, cols = mapping[which]
    rows = execute(f"SELECT {','.join(cols)} FROM {table}", fetch=True)
    # build CSV
    from io import StringIO
    si = StringIO()
    writer = csv.writer(si)
    writer.writerow(cols)
    for r in rows:
        writer.writerow([r[c] for c in cols])
    output = si.getvalue()
    from flask import Response
    return Response(output, mimetype='text/csv', headers={
        'Content-Disposition': f'attachment; filename="{which}.csv"'
    })


@app.route("/admin/jobs")
@admin_required
def admin_jobs():
    rows = execute("SELECT * FROM jobs", fetch=True)
    return render_template(
        "admin/list.html",
        title="Jobs",
        rows=[dict(r) for r in rows],
        add_url="admin_add_job",
        edit_url_base="admin_edit_job",
        delete_url_base="admin_delete_job"
    )


@app.route("/admin/internships")
@admin_required
def admin_internships():
    rows = execute("SELECT * FROM internships", fetch=True)
    return render_template(
        "admin/list.html",
        title="Internships",
        rows=[dict(r) for r in rows],
        add_url="admin_add_intern",
        edit_url_base="admin_edit_intern",
        delete_url_base="admin_delete_intern"
    )


@app.route("/admin/courses/add", methods=["GET", "POST"])
@admin_required
def admin_add_course():
    if request.method == "POST":
        d = request.form
        execute("INSERT INTO courses (title, category, price, link, image_url) VALUES (?, ?, ?, ?, ?)",
                (d["title"], d["category"], d["price"], d["link"], d.get("image_url", "")))
        safe_flash("Course added", "success")
        return redirect(url_for("admin_courses"))
    return render_template("admin/form_course.html", title="Add Course", data={})


@app.route("/admin/jobs/add", methods=["GET", "POST"])
@admin_required
def admin_add_job():
    if request.method == "POST":
        d = request.form
        execute("INSERT INTO jobs (title, company, city, salary, description, logo_url, apply_url) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (d["title"], d.get("company"), d.get("city"), d.get("salary"), d.get("description"), d.get("logo_url"), d.get("apply_url")))
        safe_flash("Job added", "success")
        return redirect(url_for("admin_jobs"))
    return render_template("admin/form_job.html", title="Add Job", data={})


@app.route("/admin/courses/edit/<int:id>", methods=["GET", "POST"])
@admin_required
def admin_edit_course(id):
    if request.method == "POST":
        d = request.form
        execute("UPDATE courses SET title=?, category=?, price=?, link=?, image_url=? WHERE id=?",
                (d["title"], d["category"], d["price"], d["link"], d.get("image_url", ""), id))
        safe_flash("Course updated", "success")
        return redirect(url_for("admin_courses"))
    rows = execute("SELECT * FROM courses WHERE id=?", (id,), fetch=True)
    data = dict(rows[0]) if rows else {}
    return render_template("admin/form_course.html", title="Edit Course", data=data)


@app.route("/admin/jobs/edit/<int:id>", methods=["GET", "POST"])
@admin_required
def admin_edit_job(id):
    if request.method == "POST":
        d = request.form
        execute("UPDATE jobs SET title=?, company=?, city=?, salary=?, description=?, logo_url=?, apply_url=? WHERE id=?",
                (d["title"], d.get("company"), d.get("city"), d.get("salary"), d.get("description"), d.get("logo_url"), d.get("apply_url"), id))
        safe_flash("Job updated", "success")
        return redirect(url_for("admin_jobs"))
    rows = execute("SELECT * FROM jobs WHERE id=?", (id,), fetch=True)
    data = dict(rows[0]) if rows else {}
    return render_template("admin/form_job.html", title="Edit Job", data=data)


@app.route("/admin/courses/delete/<int:id>")
@admin_required
def admin_delete_course(id):
    execute("DELETE FROM courses WHERE id=?", (id,))
    safe_flash("Course removed", "info")
    return redirect(url_for("admin_courses"))


@app.route("/admin/jobs/delete/<int:id>")
@admin_required
def admin_delete_job(id):
    execute("DELETE FROM jobs WHERE id=?", (id,))
    safe_flash("Job removed", "info")
    return redirect(url_for("admin_jobs"))


@app.route("/admin/internships/add", methods=["GET", "POST"])
@admin_required
def admin_add_intern():
    if request.method == "POST":
        d = request.form
        execute("INSERT INTO internships (company, role, stipend, logo_url) VALUES (?, ?, ?, ?)",
                (d.get("company"), d.get("role"), d.get("stipend"), d.get("logo_url")))
        safe_flash("Internship added", "success")
        return redirect(url_for("admin_internships"))
    return render_template("admin/form_intern.html", title="Add Internship", data={})


@app.route("/admin/internships/edit/<int:id>", methods=["GET", "POST"])
@admin_required
def admin_edit_intern(id):
    if request.method == "POST":
        d = request.form
        execute("UPDATE internships SET company=?, role=?, stipend=?, logo_url=? WHERE id=?",
                (d.get("company"), d.get("role"), d.get("stipend"), d.get("logo_url"), id))
        safe_flash("Internship updated", "success")
        return redirect(url_for("admin_internships"))
    rows = execute("SELECT * FROM internships WHERE id=?", (id,), fetch=True)
    data = dict(rows[0]) if rows else {}
    return render_template("admin/form_intern.html", title="Edit Internship", data=data)


@app.route("/admin/internships/delete/<int:id>")
@admin_required
def admin_delete_intern(id):
    execute("DELETE FROM internships WHERE id=?", (id,))
    safe_flash("Internship removed", "info")
    return redirect(url_for("admin_internships"))


@app.route('/admin/feedback')
@admin_required
def admin_feedback():
    rows = execute("SELECT id, name, email, message, rating, created_at FROM feedback ORDER BY created_at DESC", fetch=True)
    return render_template('admin/feedback_list.html', rows=[dict(r) for r in rows])


@app.route('/admin/feedback/<int:id>')
@admin_required
def admin_feedback_detail(id):
    rows = execute('SELECT id, name, email, message, rating, created_at FROM feedback WHERE id=?', (id,), fetch=True)
    if not rows:
        safe_flash('Feedback not found', 'error')
        return redirect(url_for('admin_feedback'))
    r = dict(rows[0])
    return render_template('admin/feedback_detail.html', r=r)


@app.route('/admin/feedback/delete/<int:id>')
@admin_required
def admin_delete_feedback(id):
    execute('DELETE FROM feedback WHERE id=?', (id,))
    safe_flash('Feedback removed', 'info')
    return redirect(url_for('admin_feedback'))



# -----------------------------------------------------
# START APP
# -----------------------------------------------------
if __name__ == "__main__":
    # init DB and set a secret key for the admin session
    try:
        init_db()
    except Exception as e:
        import traceback
        traceback.print_exc()
        print("Database initialization failed:", e)
        sys.exit(1)

    app.config.setdefault("SECRET_KEY", os.environ.get("FLASK_SECRET", "devkey123"))
    # admin password environment variable is optional; default = ravi@123
    # To override, set the ADMIN_PASSWORD environment variable before starting the app.
    app.config.setdefault("ADMIN_PASSWORD", os.environ.get("ADMIN_PASSWORD", "ravi@123"))

    try:
        print("Starting Flask app on http://127.0.0.1:5000 — debug=True for local testing")
        # Use debug=True for clearer error output locally; change to False for production
        app.run(host='127.0.0.1', debug=True)
    except Exception as e:
        import traceback
        traceback.print_exc()
        print("Flask server failed to start:", e)
        sys.exit(1)
if __name__ == "__main__":
    app.run(debug=True)
