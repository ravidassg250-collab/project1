# AI Career Hub — Flask

## Quickstart

```bash
pip install -r requirements.txt
python app.py
```

Then open http://127.0.0.1:5000/

## Admin Panel

The app includes a simple admin panel at `/admin` with minimal CRUD for `courses`, `jobs`, and `internships`.

- Default admin password: `admin123` (set `ADMIN_PASSWORD` env var to override)
- Default session secret: `FLASK_SECRET` env var may be set, otherwise a dev key is used

## Structure

```
ai_career_hub/
├── app.py
├── requirements.txt
├── static/
│   └── style.css
└── templates/
    ├── index.html
    ├── jobs.html
    ├── courses.html
    ├── internships.html
    ├── resume-analyzer.html
    ├── resume-builder.html
    ├── career-predictor.html
    └── r.html
```
